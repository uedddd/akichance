import logging
import os
import pyodbc
import requests
import json
from datetime import datetime
import azure.functions as func

app = func.FunctionApp()

@app.timer_trigger(
    schedule="0 */1 * * * *",
    arg_name="myTimer",
    use_monitor=False
)
def CheckUnseatedReservation(myTimer: func.TimerRequest) -> None:

    # ----------------------------------------
    # 実行開始ログ
    # ----------------------------------------
    if myTimer.past_due:
        logging.info("タイマーが遅延して実行されました")

    logging.info("未着席チェック開始: %s", datetime.now())

    # ----------------------------------------
    # 環境変数から設定を取得
    # ----------------------------------------
    conn_str    = os.environ["SQL_CONNECTION_STRING"]
    webhook_url = os.environ["POWER_AUTOMATE_WEBHOOK_URL"]
    fastapi_url = os.environ["FASTAPI_BASE_URL"]

    # ----------------------------------------
    # Azure SQL DB に接続
    # ----------------------------------------
    try:
        conn = pyodbc.connect(conn_str)
        cursor = conn.cursor()
        logging.info("DB接続成功")

    except Exception as e:
        logging.error("DB接続エラー: %s", str(e))
        return

    # ----------------------------------------
    # ① 未着席の予約を検索
    # ----------------------------------------
    try:
        query = """
            SELECT
                r.reservation_id,
                r.seat_id,
                r.user_id,
                r.start_datetime,
                r.end_datetime,
                u.email,
                u.display_name,
                s.seat_name
            FROM reservations r
            JOIN users u ON r.user_id = u.user_id
            JOIN seats s ON r.seat_id = s.seat_id
            WHERE r.status = 'reserved'
            AND r.start_datetime < GETDATE()
            AND r.notified_at IS NULL
        """
        cursor.execute(query)
        rows = cursor.fetchall()
        logging.info("未着席件数: %d 件", len(rows))

    except Exception as e:
        logging.error("クエリエラー: %s", str(e))
        conn.close()
        return

    # ----------------------------------------
    # ② 該当予約ごとに Teams通知を送信
    # ----------------------------------------
    for row in rows:
        reservation_id = row[0]
        seat_id        = row[1]
        user_id        = row[2]
        start_datetime = row[3]
        end_datetime   = row[4]
        email          = row[5]
        display_name   = row[6]
        seat_name      = row[7]

        logging.info(
            "通知送信対象: reservation_id=%d, seat=%s, user=%s",
            reservation_id, seat_name, display_name
        )

        # ----------------------------------------
        # Teams Adaptive Card メッセージ作成
        # ----------------------------------------
        message = {
            "type": "message",
            "attachments": [
                {
                    "contentType": "application/vnd.microsoft.card.adaptive",
                    "content": {
                        "$schema": "http://adaptivecards.io/schemas/adaptive-card.json",
                        "type": "AdaptiveCard",
                        "version": "1.4",
                        "body": [
                            {
                                "type": "TextBlock",
                                "text": "⚠️ 未着席アラート",
                                "weight": "Bolder",
                                "size": "Large",
                                "color": "Warning"
                            },
                            {
                                "type": "FactSet",
                                "facts": [
                                    {
                                        "title": "予約者",
                                        "value": display_name
                                    },
                                    {
                                        "title": "席番号",
                                        "value": seat_name
                                    },
                                    {
                                        "title": "予約開始時刻",
                                        "value": str(start_datetime)
                                    },
                                    {
                                        "title": "予約終了時刻",
                                        "value": str(end_datetime)
                                    }
                                ]
                            },
                            {
                                "type": "TextBlock",
                                "text": "予約時刻を過ぎても着席が確認できません。\nどちらかを選択してください。",
                                "wrap": True
                            }
                        ],
                        "actions": [
                            {
                                "type": "Action.Http",
                                "title": "✅ 承認（使用中にする）",
                                "method": "POST",
                                "url": f"{fastapi_url}/reservations/approve",
                                "body": json.dumps({
                                    "reservation_id": reservation_id
                                }),
                                "headers": [
                                    {
                                        "name": "Content-Type",
                                        "value": "application/json"
                                    }
                                ]
                            },
                            {
                                "type": "Action.Http",
                                "title": "❌ キャンセル",
                                "method": "POST",
                                "url": f"{fastapi_url}/reservations/cancel",
                                "body": json.dumps({
                                    "reservation_id": reservation_id
                                }),
                                "headers": [
                                    {
                                        "name": "Content-Type",
                                        "value": "application/json"
                                    }
                                ]
                            }
                        ]
                    }
                }
            ]
        }

        # ----------------------------------------
        # Teams に送信
        # ----------------------------------------
        try:
            response = requests.post(
                webhook_url,
                json=message,
                timeout=10
            )
            logging.info(
                "Teams送信結果: status=%d, reservation_id=%d",
                response.status_code,
                reservation_id
            )

        except Exception as e:
            logging.error(
                "Teams送信エラー: reservation_id=%d, error=%s",
                reservation_id, str(e)
            )
            continue

        # ----------------------------------------
        # ③ notified_at を更新
        # ----------------------------------------
        try:
            update_query = """
                UPDATE reservations
                SET notified_at = GETDATE(),
                    updated_at  = GETDATE()
                WHERE reservation_id = ?
            """
            cursor.execute(update_query, reservation_id)
            conn.commit()
            logging.info(
                "notified_at 更新完了: reservation_id=%d",
                reservation_id
            )

        except Exception as e:
            logging.error(
                "UPDATE エラー: reservation_id=%d, error=%s",
                reservation_id, str(e)
            )

    # ----------------------------------------
    # DB接続を閉じる
    # ----------------------------------------
    conn.close()
    logging.info("未着席チェック完了")