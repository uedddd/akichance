import azure.functions as func
import json
import logging
import os
from sqlalchemy import create_engine, text

app = func.FunctionApp()


def get_engine():
    server   = os.environ["SQL_SERVER"]
    database = os.environ["SQL_DATABASE"]
    user     = os.environ["SQL_USER"]
    password = os.environ["SQL_PASSWORD"]

    conn_str = (
        f"mssql+pymssql://{user}:{password}@{server}/{database}"
    )
    return create_engine(conn_str)


# 全席取得
@app.route(route="seats", methods=["GET"], auth_level=func.AuthLevel.ANONYMOUS)
def GetSeats(req: func.HttpRequest) -> func.HttpResponse:
    logging.info("GetSeats called")
    try:
        engine = get_engine()
        with engine.connect() as conn:
            rows = conn.execute(
                text("SELECT seat_id, floor_id, seat_name, status FROM seats WHERE is_active = 1")
            ).fetchall()

        seats = [
            {
                "seat_id":   r.seat_id,
                "floor_id":  r.floor_id,
                "seat_name": r.seat_name,
                "status":    r.status
            }
            for r in rows
        ]

        return func.HttpResponse(
            json.dumps(seats, ensure_ascii=False),
            mimetype="application/json",
            status_code=200
        )
    except Exception as e:
        logging.error(f"エラー: {e}")
        return func.HttpResponse(
            json.dumps({"error": str(e)}),
            mimetype="application/json",
            status_code=500
        )


# トグル
@app.route(route="seats/{seat_id}/toggle", methods=["PATCH"], auth_level=func.AuthLevel.ANONYMOUS)
def ToggleSeat(req: func.HttpRequest) -> func.HttpResponse:
    seat_id = req.route_params.get("seat_id")
    logging.info(f"ToggleSeat called: seat_id={seat_id}")
    try:
        engine = get_engine()
        with engine.begin() as conn:
            row = conn.execute(
                text("SELECT status FROM seats WHERE seat_id = :id"),
                {"id": seat_id}
            ).fetchone()

            if row is None:
                return func.HttpResponse(
                    json.dumps({"error": "seat not found"}),
                    mimetype="application/json",
                    status_code=404
                )

            new_status = "in_use" if row.status == "empty" else "empty"

            conn.execute(
                text("""
                    UPDATE seats
                    SET status = :status, updated_at = GETDATE()
                    WHERE seat_id = :id
                """),
                {"status": new_status, "id": seat_id}
            )

        return func.HttpResponse(
            json.dumps({"seat_id": seat_id, "status": new_status}),
            mimetype="application/json",
            status_code=200
        )
    except Exception as e:
        logging.error(f"エラー: {e}")
        return func.HttpResponse(
            json.dumps({"error": str(e)}),
            mimetype="application/json",
            status_code=500
        )


# IoT Hubからのトグル
@app.route(route="iot/toggle", methods=["POST"], auth_level=func.AuthLevel.ANONYMOUS)
def IotHubTrigger(req: func.HttpRequest) -> func.HttpResponse:
    logging.info("IotHubTrigger called")
    try:
        body = req.get_json()
        seat_id = body.get("seat_id")
        action  = body.get("action")

        if action != "toggle":
            return func.HttpResponse(
                json.dumps({"error": "unsupported action"}),
                mimetype="application/json",
                status_code=400
            )

        engine = get_engine()
        with engine.connect() as conn:
            row = conn.execute(
                text("SELECT status FROM seats WHERE seat_id = :id"),
                {"id": seat_id}
            ).fetchone()

            if row is None:
                return func.HttpResponse(
                    json.dumps({"error": "seat not found"}),
                    mimetype="application/json",
                    status_code=404
                )

            new_status = "in_use" if row.status == "empty" else "empty"

            conn.execute(
                text("""
                    UPDATE seats
                    SET status = :status, updated_at = GETDATE()
                    WHERE seat_id = :id
                """),
                {"status": new_status, "id": seat_id}
            )
            conn.commit()

        return func.HttpResponse(
            json.dumps({"seat_id": seat_id, "status": new_status}),
            mimetype="application/json",
            status_code=200
        )
    except Exception as e:
        logging.error(f"エラー: {e}")
        return func.HttpResponse(
            json.dumps({"error": str(e)}),
            mimetype="application/json",
            status_code=500
        )

        @app.event_hub_message_trigger(
    arg_name="event",
    event_hub_name="akichanceiothub",
    connection="IOT_HUB_CONNECTION_STRING"
)
def IotHubTrigger(event: func.EventHubEvent):
    body = json.loads(event.get_body().decode("utf-8"))
    seat_id = body.get("seat_id")
    action  = body.get("action")

    logging.info(f"受信: seat_id={seat_id}, action={action}")

    if action != "toggle":
        logging.warning(f"未対応のaction: {action}")
        return

    try:
        engine = get_engine()
        with engine.begin() as conn:
            row = conn.execute(
                text("SELECT status FROM seats WHERE seat_id = :id"),
                {"id": seat_id}
            ).fetchone()

            if row is None:
                logging.error(f"seat_id={seat_id} が見つかりません")
                return

            new_status = "in_use" if row.status == "empty" else "empty"

            conn.execute(
                text("""
                    UPDATE seats
                    SET status = :status, updated_at = GETDATE()
                    WHERE seat_id = :id
                """),
                {"status": new_status, "id": seat_id}
            )

        logging.info(f"seat_id={seat_id} → {new_status} に更新しました")

    except Exception as e:
        logging.error(f"エラー: {e}")