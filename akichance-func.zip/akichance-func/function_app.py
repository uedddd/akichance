import azure.functions as func
import json
import logging
import os
import pyodbc
import requests
from datetime import datetime
from sqlalchemy import create_engine, text

app = func.FunctionApp()


def get_engine():
    server   = os.environ["SQL_SERVER"]
    database = os.environ["SQL_DATABASE"]
    user     = os.environ["SQL_USER"]
    password = os.environ["SQL_PASSWORD"]
    conn_str = (
        f"mssql+pymssql://{user}:{password}@{server}/{database}"
    )
    return create_engine(conn_str)


# 全席取得
@app.route(route="seats", methods=["GET"], auth_level=func.AuthLevel.ANONYMOUS)
def GetSeats(req: func.HttpRequest) -> func.HttpResponse:
    logging.info("GetSeats called")
    try:
        engine = get_engine()
        with engine.connect() as conn:
            rows = conn.execute(
                text("SELECT seat_id, floor_id, seat_name, status FROM seats WHERE is_active = 1")
            ).fetchall()

        seats = [
            {
                "seat_id":   r.seat_id,
                "floor_id":  r.floor_id,
                "seat_name": r.seat_name,
                "status":    r.status
            }
            for r in rows
        ]

        return func.HttpResponse(
            json.dumps(seats, ensure_ascii=False),
            mimetype="application/json",
            status_code=200
        )
    except Exception as e:
        logging.error(f"エラー: {e}")
        return func.HttpResponse(
            json.dumps({"error": str(e)}),
            mimetype="application/json",
            status_code=500
        )


# トグル
@app.route(route="seats/{seat_id}/toggle", methods=["PATCH"], auth_level=func.AuthLevel.ANONYMOUS)
def ToggleSeat(req: func.HttpRequest) -> func.HttpResponse:
    seat_id = req.route_params.get("seat_id")
    logging.info(f"ToggleSeat called: seat_id={seat_id}")
    try:
        engine = get_engine()
        with engine.begin() as conn:
            row = conn.execute(
                text("SELECT status FROM seats WHERE seat_id = :id"),
                {"id": seat_id}
            ).fetchone()

            if row is None:
                return func.HttpResponse(
                    json.dumps({"error": "seat not found"}),
                    mimetype="application/json",
                    status_code=404
                )

            new_status = "in_use" if row.status == "empty" else "empty"

            conn.execute(
                text("""
                    UPDATE seats
                    SET status = :status, updated_at = GETDATE()
                    WHERE seat_id = :id
                """),
                {"status": new_status, "id": seat_id}
            )

        return func.HttpResponse(
            json.dumps({"seat_id": seat_id, "status": new_status}),
            mimetype="application/json",
            status_code=200
        )
    except Exception as e:
        logging.error(f"エラー: {e}")
        return func.HttpResponse(
            json.dumps({"error": str(e)}),
            mimetype="application/json",
            status_code=500
        )


# IoT Hub Event Hub Trigger
@app.event_hub_message_trigger(
    arg_name="event",
    event_hub_name="akichanceiothub",
    connection="IOT_HUB_CONNECTION_STRING",
    cardinality="one",
    consumer_group="$Default"
)
def IotHubEventTrigger(event: func.EventHubEvent):
    body = json.loads(event.get_body().decode("utf-8"))
    seat_id = body.get("seatId")
    status  = body.get("status")

    logging.info(f"受信: seat_id={seat_id}, status={status}")

    if status not in ["in_use", "available"]:
        logging.warning(f"未対応のstatus: {status}")
        return

    new_status = "in_use" if status == "in_use" else "empty"

    try:
        engine = get_engine()
        with engine.begin() as conn:
            row = conn.execute(
                text("SELECT status FROM seats WHERE seat_id = :id"),
                {"id": seat_id}
            ).fetchone()

            if row is None:
                logging.error(f"seat_id={seat_id} が見つかりません")
                return

            conn.execute(
                text("""
                    UPDATE seats
                    SET status = :status, updated_at = GETDATE()
                    WHERE seat_id = :id
                """),
                {"status": new_status, "id": seat_id}
            )

        logging.info(f"seat_id={seat_id} → {new_status} に更新しました")

    except Exception as e:
        logging.error(f"エラー: {e}")


# 未着席チェック
@app.timer_trigger(
    schedule="0 */1 * * * *",
    arg_name="myTimer",
    use_monitor=False
)
def CheckUnseatedReservation(myTimer: func.TimerRequest) -> None:
    if myTimer.past_due:
        logging.info("タイマーが遅延して実行されました")

    logging.info("未着席チェック開始: %s", datetime.now())

    conn_str    = os.environ["SQL_CONNECTION_STRING"]
    webhook_url = os.environ["POWER_AUTOMATE_WEBHOOK_URL"]
    fastapi_url = os.environ["FASTAPI_BASE_URL"]

    try:
        conn = pyodbc.connect(conn_str)
        cursor = conn.cursor()
        logging.info("DB接続成功")
    except Exception as e:
        logging.error("DB接続エラー: %s", str(e))
        return

    try:
        query = """
            SELECT
                r.reservation_id,
                r.seat_id,
                r.user_id,
                r.start_datetime,
                r.end_datetime,
                u.email,
                u.display_name,
                s.seat_name
            FROM reservations r
            JOIN users u ON r.user_id = u.user_id
            JOIN seats s ON r.seat_id = s.seat_id
            WHERE r.status = 'reserved'
            AND r.start_datetime < GETDATE()
            AND r.notified_at IS NULL
        """
        cursor.execute(query)
        rows = cursor.fetchall()
        logging.info("未着席件数: %d 件", len(rows))
    except Exception as e:
        logging.error("クエリエラー: %s", str(e))
        conn.close()
        return

    for row in rows:
        reservation_id = row[0]
        seat_id        = row[1]
        user_id        = row[2]
        start_datetime = row[3]
        end_datetime   = row[4]
        email          = row[5]
        display_name   = row[6]
        seat_name      = row[7]

        message = {
            "type": "message",
            "attachments": [
                {
                    "contentType": "application/vnd.microsoft.card.adaptive",
                    "content": {
                        "$schema": "http://adaptivecards.io/schemas/adaptive-card.json",
                        "type": "AdaptiveCard",
                        "version": "1.4",
                        "body": [
                            {
                                "type": "TextBlock",
                                "text": "⚠️ 未着席アラート",
                                "weight": "Bolder",
                                "size": "Large",
                                "color": "Warning"
                            },
                            {
                                "type": "FactSet",
                                "facts": [
                                    {"title": "予約者", "value": display_name},
                                    {"title": "席番号", "value": seat_name},
                                    {"title": "予約開始時刻", "value": str(start_datetime)},
                                    {"title": "予約終了時刻", "value": str(end_datetime)}
                                ]
                            },
                            {
                                "type": "TextBlock",
                                "text": "予約時刻を過ぎても着席が確認できません。\nどちらかを選択してください。",
                                "wrap": True
                            }
                        ],
                        "actions": [
                            {
                                "type": "Action.Http",
                                "title": "✅ 承認（使用中にする）",
                                "method": "POST",
                                "url": f"{fastapi_url}/reservations/approve",
                                "body": json.dumps({"reservation_id": reservation_id}),
                                "headers": [{"name": "Content-Type", "value": "application/json"}]
                            },
                            {
                                "type": "Action.Http",
                                "title": "❌ キャンセル",
                                "method": "POST",
                                "url": f"{fastapi_url}/reservations/cancel",
                                "body": json.dumps({"reservation_id": reservation_id}),
                                "headers": [{"name": "Content-Type", "value": "application/json"}]
                            }
                        ]
                    }
                }
            ]
        }

        try:
            response = requests.post(webhook_url, json=message, timeout=10)
            logging.info("Teams送信結果: status=%d, reservation_id=%d", response.status_code, reservation_id)
        except Exception as e:
            logging.error("Teams送信エラー: reservation_id=%d, error=%s", reservation_id, str(e))
            continue

        try:
            cursor.execute(
                "UPDATE reservations SET notified_at = GETDATE(), updated_at = GETDATE() WHERE reservation_id = ?",
                reservation_id
            )
            conn.commit()
            logging.info("notified_at 更新完了: reservation_id=%d", reservation_id)
        except Exception as e:
            logging.error("UPDATE エラー: reservation_id=%d, error=%s", reservation_id, str(e))

    conn.close()
    logging.info("未着席チェック完了")